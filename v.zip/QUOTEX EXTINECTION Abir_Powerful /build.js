const gulp = require('gulp');
const rimraf = require('rimraf');
const obfuscator = require('gulp-javascript-obfuscator');

rimraf.sync('dist');

gulp.src('background.js')
    .pipe(obfuscator())
    .pipe(gulp.dest('dist'));

gulp.src(['assets/js/popup.js'])
    .pipe(obfuscator())
    .pipe(gulp.dest('dist/assets/js'));

gulp.src(['manifest.json', 'icon.png', 'popup.html'])
    .pipe(gulp.dest('dist'));

gulp.src(['assets/css/*'])
    .pipe(gulp.dest('dist/assets/css'));

gulp.src(['assets/img/*'])
    .pipe(gulp.dest('dist/assets/img'));