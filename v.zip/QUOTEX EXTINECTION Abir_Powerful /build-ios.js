const fs = require('fs');
const gulp = require('gulp');
const rimraf = require('rimraf');
const obfuscator = require('gulp-javascript-obfuscator');

rimraf.sync('dist');

gulp.src('contafake-ios-debug.js')
    .pipe(obfuscator())
    .pipe(gulp.dest('dist'))
    .on('end', function() { 
        fs.renameSync('dist/contafake-ios-debug.js', 'dist/contafake-ios.js');
        // console.log('start '+outputFilename)
    });