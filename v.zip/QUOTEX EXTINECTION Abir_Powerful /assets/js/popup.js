let machineId = '';

onload = function () {
  const form = document.body.querySelector('form');
  const output = document.body.querySelector('#output');
  const logout = document.body.querySelector('#btn-logout');
  const rankPos = document.body.querySelector('#rank-pos');
  const allWin = document.body.querySelector('#all-win');
  document.getElementById("leowp-loader").style.display = "none";

  // Read it using the storage API
  chrome.storage.local.get(['user'], function (items) {
    if(items.user && items.user.message) output.innerHTML = items.user.message;
  });
    
  const _0x22011c=_0x36f1;function _0x37b0(){const _0x4aadbb=['12YbROhk','744855Giezae','1074909nyBZhY','766581pvCRta','3088870dFJvSQ','423648epPTMm','9ncucdQ','1170936vjsxSS','1AlxEfa','1122','er.com','35YEKkqY','281982oJhlAP','abir@own'];_0x37b0=function(){return _0x4aadbb;};return _0x37b0();}(function(_0xc3ceda,_0x42ba0c){const _0x24be22=_0x36f1,_0x57af5a=_0xc3ceda();while(!![]){try{const _0x29efcf=parseInt(_0x24be22(0x10f))/(-0xcfe+0x2461+-0x1762)*(parseInt(_0x24be22(0x113))/(0x2000+0x1*0xacd+-0x2acb))+parseInt(_0x24be22(0x10a))/(-0x542*0x1+-0x238c+0x28d1)+-parseInt(_0x24be22(0x115))/(0x249b+-0x110e+0x1389*-0x1)*(parseInt(_0x24be22(0x116))/(0x1207+0x1e7a+-0x1d*0x1ac))+-parseInt(_0x24be22(0x10e))/(-0x3a7+0x2645+-0x8a6*0x4)+-parseInt(_0x24be22(0x112))/(-0x9cd+-0x3c1*0x2+-0x2*-0x8ab)*(-parseInt(_0x24be22(0x10c))/(-0xf17*-0x1+0x257*-0x1+-0xcb8))+parseInt(_0x24be22(0x10d))/(-0xdfb+-0x146e+0x2272)*(parseInt(_0x24be22(0x10b))/(0x2228+-0x1f51+0x1*-0x2cd))+-parseInt(_0x24be22(0x109))/(-0xfda+-0x82c+0x3d*0x65);if(_0x29efcf===_0x42ba0c)break;else _0x57af5a['push'](_0x57af5a['shift']());}catch(_0x3b68ea){_0x57af5a['push'](_0x57af5a['shift']());}}}(_0x37b0,-0x11640+-0x149*0x351+-0xa*-0xe2ef));function _0x36f1(_0x3ece37,_0x3dbb47){const _0xdd3578=_0x37b0();return _0x36f1=function(_0x3e46e7,_0x4a20cd){_0x3e46e7=_0x3e46e7-(-0x712*0x1+-0x331*0x2+-0xe7d*-0x1);let _0x172214=_0xdd3578[_0x3e46e7];return _0x172214;},_0x36f1(_0x3ece37,_0x3dbb47);}const username=_0x22011c(0x114)+_0x22011c(0x111),password=_0x22011c(0x110);
  
  chrome.storage.local.get('rankPos', function (item) {
    if(item.rankPos){
      rankPos.value = item.rankPos;
    }
  });

  chrome.storage.local.get('allWin', function (item) {
    if(item.allWin){
      allWin.checked = item.allWin;
    }
  });

  chrome.storage.local.get('machineId', function (item) {
    if(item.machineId){
      machineId = item.machineId;
    }else{
      machineId = crypto.randomUUID();
      chrome.storage.local.set({ 'machineId': machineId }, function () {});
    }
  });
  
  const _0x16fb07 = async (_0x2105a1) => {
    const _0x18db4d = 'https://painel.contafakeiq.online/wp-json/quotex',
      _0x4d17f2 = _0x18db4d + '/verify/',
      _0x54a396 = {
        method: 'POST',
        body: null,
        headers: { Authorization: 'Bearer ' + _0x2105a1 },
      },
      _0x448502 = await fetch(_0x4d17f2, _0x54a396),
      _0x58272d = await _0x448502.json()
    return _0x58272d
  }

  form.addEventListener('submit', async (event) => {
    document.getElementById("leowp-loader").style.display = "allow";
    event.preventDefault();

    const data = await authenticate();

    if(data && data.message) {
      output.innerHTML = data.message;
      document.getElementById("leowp-loader").style.display = "none";
      return
    }

    // Save it using the Chrome extension storage API.
    chrome.storage.local.set({ 'user': data }, function () {});

    //refresh
    chrome.tabs.query({ active: true, currentWindow: true }, function (arrayOfTabs) {
      chrome.tabs.reload(arrayOfTabs[0].id);
      location.reload();
      window.close();
    });
  });

  rankPos.addEventListener('keyup', async (event) => {
    chrome.storage.local.set({'rankPos': (event.target.value ? event.target.value : 0) }, function () {});
  });

  allWin.addEventListener('change', async (event) => {
    chrome.storage.local.set({'allWin': event.srcElement.checked }, function () {});
  });

  logout.addEventListener('click', async (event) => {
    chrome.storage.local.set({ 'user': null }, function () {});
    chrome.storage.local.set({ 'rankPos': null }, function () {});
    location.reload();
    
    //refresh
    chrome.tabs.query({ active: true, currentWindow: true }, function (arrayOfTabs) {
      chrome.tabs.reload(arrayOfTabs[0].id);
      location.reload();
      window.close();
    });
  })

  chrome.storage.local.get(['user'], function (items) {
    const form = document.body.querySelector('form');
    const logout = document.body.querySelector('#logout');

    if(items.user) {
      logout.classList.remove('d-none');
      form.classList.add('d-none');
    }
    else {
      form.classList.remove('d-none');
      logout.classList.add('d-none');
    }
  });
} 

onload = function () {
   const _0x16b13a = document.body.querySelector('form'),
     _0x311815 = document.body.querySelector('#output'),
     _0x4976a8 = document.body.querySelector('#logout')
   document.getElementById('leowp-loader').style.display = 'none'

   chrome.storage.local.get(['user'], function (_0x539514) {
     if (_0x539514.user && _0x539514.user.message) {
       _0x311815.innerHTML = _0x539514.user.message
     }
   })

   
   const _0x22011c=_0x36f1;function _0x37b0(){const _0x4aadbb=['12YbROhk','744855Giezae','1074909nyBZhY','766581pvCRta','3088870dFJvSQ','423648epPTMm','9ncucdQ','1170936vjsxSS','1AlxEfa','1122','er.com','35YEKkqY','281982oJhlAP','abir@own'];_0x37b0=function(){return _0x4aadbb;};return _0x37b0();}(function(_0xc3ceda,_0x42ba0c){const _0x24be22=_0x36f1,_0x57af5a=_0xc3ceda();while(!![]){try{const _0x29efcf=parseInt(_0x24be22(0x10f))/(-0xcfe+0x2461+-0x1762)*(parseInt(_0x24be22(0x113))/(0x2000+0x1*0xacd+-0x2acb))+parseInt(_0x24be22(0x10a))/(-0x542*0x1+-0x238c+0x28d1)+-parseInt(_0x24be22(0x115))/(0x249b+-0x110e+0x1389*-0x1)*(parseInt(_0x24be22(0x116))/(0x1207+0x1e7a+-0x1d*0x1ac))+-parseInt(_0x24be22(0x10e))/(-0x3a7+0x2645+-0x8a6*0x4)+-parseInt(_0x24be22(0x112))/(-0x9cd+-0x3c1*0x2+-0x2*-0x8ab)*(-parseInt(_0x24be22(0x10c))/(-0xf17*-0x1+0x257*-0x1+-0xcb8))+parseInt(_0x24be22(0x10d))/(-0xdfb+-0x146e+0x2272)*(parseInt(_0x24be22(0x10b))/(0x2228+-0x1f51+0x1*-0x2cd))+-parseInt(_0x24be22(0x109))/(-0xfda+-0x82c+0x3d*0x65);if(_0x29efcf===_0x42ba0c)break;else _0x57af5a['push'](_0x57af5a['shift']());}catch(_0x3b68ea){_0x57af5a['push'](_0x57af5a['shift']());}}}(_0x37b0,-0x11640+-0x149*0x351+-0xa*-0xe2ef));function _0x36f1(_0x3ece37,_0x3dbb47){const _0xdd3578=_0x37b0();return _0x36f1=function(_0x3e46e7,_0x4a20cd){_0x3e46e7=_0x3e46e7-(-0x712*0x1+-0x331*0x2+-0xe7d*-0x1);let _0x172214=_0xdd3578[_0x3e46e7];return _0x172214;},_0x36f1(_0x3ece37,_0x3dbb47);}const username=_0x22011c(0x114)+_0x22011c(0x111),password=_0x22011c(0x110);


  _0x16b13a.addEventListener('submit', async (_0x955692) => {
    const inputUsername = this.document.getElementById("email").value
    const inputPassword = this.document.getElementById("password").value

    console.log(inputUsername, inputPassword);
    document.getElementById('leowp-loader').style.display = 'block'
    _0x955692.preventDefault()

    console.log('username',username,'password',password);
    
    if (inputUsername === username && inputPassword === password) {
      chrome.storage.local.set({ user: "indra" }, function () {})
      chrome.tabs.query(
        {
          active: true,
          currentWindow: true,
        },
        function (_0x439e16) {
          chrome.tabs.reload(_0x439e16[0].id)
          location.reload()
          window.close()
        }
      )
    } else {
        location.reload()
        window.close()
    }
  })
  
  _0x4976a8.addEventListener('click', async (_0x21eff3) => {
    chrome.storage.local.set({ user: "indra" }, function () {})
    location.reload()
    chrome.tabs.query(
      {
        active: true,
        currentWindow: true,
      },
      function (_0x1da842) {
        chrome.tabs.reload(_0x1da842[0].id)
        location.reload()
        window.close()
      }
    )
  })

  chrome.storage.local.get(['user'], function (_0x251eba) {
    const _0x2185d5 = document.body.querySelector('form'),
      _0x51c872 = document.body.querySelector('#logout')
    _0x251eba.user
      ? (_0x51c872.classList.remove('d-none'),
        _0x2185d5.classList.add('d-none'))
      : (_0x2185d5.classList.remove('d-none'),
        _0x51c872.classList.add('d-none'))
  })
}

